#include <DHT.h>

const byte LDR_PIN   = 36;
const byte DHT_PIN   = 13;
const byte RELAY_PIN = 12;
const byte LED_PIN   = 5; 

#define DHTTYPE DHT22
DHT dht(DHT_PIN, DHTTYPE);

const bool RELAY_ON  = LOW;  
const bool RELAY_OFF = HIGH; 

void setup() {
  Serial.begin(115200);
  dht.begin();

  pinMode(RELAY_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);

  digitalWrite(RELAY_PIN, RELAY_OFF);
  digitalWrite(LED_PIN, LOW);

  Serial.println("=== SISTEM OTOMASI WAREHOUSE SIMULASI ===");
}

void loop() {
  delay(2000);

  int ldrValue = analogRead(LDR_PIN);
  float temp   = dht.readTemperature();
  float hum    = dht.readHumidity();

  if (isnan(temp) || isnan(hum)) {
    Serial.println("[ERROR] Gagal membaca sensor DHT22!");
    return;
  }

  float ldrPercent = (ldrValue / 1023.0) * 100.0;

  Serial.print("Suhu: ");
  Serial.print(temp, 1);
  Serial.print(" °C | Kelembapan: ");
  Serial.print(hum, 1);
  Serial.print(" % | Cahaya: ");
  Serial.print(ldrValue);
  Serial.print(" (");
  Serial.print(ldrPercent, 1);
  Serial.println("%)");

  if (temp > 34.0 || ldrValue < 300) {
    digitalWrite(RELAY_PIN, RELAY_ON);
    digitalWrite(LED_PIN, HIGH);
    Serial.println("--> Status: [PERINGATAN] Relay & LED AKTIF!");
  } else {
    digitalWrite(RELAY_PIN, RELAY_OFF);
    digitalWrite(LED_PIN, LOW);
    Serial.println("--> Status: [NORMAL] Kondisi Aman.");
  }

  Serial.println("--------------------------------------------------");
}